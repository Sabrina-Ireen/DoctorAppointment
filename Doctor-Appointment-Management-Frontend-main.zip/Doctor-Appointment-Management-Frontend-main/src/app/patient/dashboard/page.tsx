'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
    Calendar,
    User,
    Clock,
    Phone,
    Mail,
    Plus,
    CheckCircle,
    XCircle,
    AlertCircle
} from 'lucide-react';
import { apiService, User as UserType, Appointment } from '@/lib/api';
import toast from 'react-hot-toast';

export default function PatientDashboard() {
    const router = useRouter();
    const [user, setUser] = useState<UserType | null>(null);
    const [appointments, setAppointments] = useState<Appointment[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const currentUser = apiService.getCurrentUser();
        if (!currentUser) {
            router.push('/login');
            return;
        }
        if (currentUser.Role !== 'Patient') {
            router.push('/');
            return;
        }
        setUser(currentUser);
        loadAppointments(currentUser.Id);
    }, [router]);

    const loadAppointments = async (patientId: string) => {
        try {
            const data = await apiService.getAppointmentsByPatient(patientId);
            setAppointments(data);
        } catch (error) {
            console.error('Error loading appointments:', error);
            toast.error('Failed to load appointments');
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Approved':
                return 'text-green-600 bg-green-100';
            case 'Pending':
                return 'text-yellow-600 bg-yellow-100';
            case 'Rejected':
                return 'text-red-600 bg-red-100';
            case 'Cancelled':
                return 'text-black bg-gray-100';
            case 'Completed':
                return 'text-blue-600 bg-blue-100';
            default:
                return 'text-black bg-gray-100';
        }
    };

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'Approved':
                return <CheckCircle className="h-4 w-4" />;
            case 'Pending':
                return <AlertCircle className="h-4 w-4" />;
            case 'Rejected':
            case 'Cancelled':
                return <XCircle className="h-4 w-4" />;
            case 'Completed':
                return <CheckCircle className="h-4 w-4" />;
            default:
                return <AlertCircle className="h-4 w-4" />;
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Quick Actions */}
            <div className="mb-8">
                <div className="bg-white rounded-lg shadow p-6">
                    <h2 className="text-lg font-medium text-black mb-4">Quick Actions</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <button
                            onClick={() => router.push('/patient/book-appointment')}
                            className="flex items-center justify-center p-4 border border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                        >
                            <Plus className="h-6 w-6 text-blue-600 mr-2" />
                            <span className="font-medium text-black">Book New Appointment</span>
                        </button>
                        <button
                            onClick={() => router.push('/patient/appointments')}
                            className="flex items-center justify-center p-4 border border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                        >
                            <Calendar className="h-6 w-6 text-blue-600 mr-2" />
                            <span className="font-medium text-black">View All Appointments</span>
                        </button>
                        <button
                            onClick={() => router.push('/patient/profile')}
                            className="flex items-center justify-center p-4 border border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                        >
                            <User className="h-6 w-6 text-blue-600 mr-2" />
                            <span className="font-medium text-black">Manage Profile</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* Profile Summary */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                <div className="bg-white rounded-lg shadow p-6">
                    <h3 className="text-lg font-medium text-black mb-4">Profile Information</h3>
                    <div className="space-y-3">
                        <div className="flex items-center">
                            <User className="h-4 w-4 text-black mr-2" />
                            <span className="text-sm text-black">{user?.Name}</span>
                        </div>
                        <div className="flex items-center">
                            <Mail className="h-4 w-4 text-black mr-2" />
                            <span className="text-sm text-black">{user?.Email}</span>
                        </div>
                        {user?.Phone && (
                            <div className="flex items-center">
                                <Phone className="h-4 w-4 text-black mr-2" />
                                <span className="text-sm text-black">{user.Phone}</span>
                            </div>
                        )}
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <h3 className="text-lg font-medium text-black mb-4">Appointment Stats</h3>
                    <div className="space-y-3">
                        <div className="flex justify-between">
                            <span className="text-sm text-black">Total Appointments</span>
                            <span className="text-sm font-medium">{appointments.length}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-sm text-black">Upcoming</span>
                            <span className="text-sm font-medium">
                                {appointments.filter(apt => apt.Status === 'Approved' || apt.Status === 'Pending').length}
                            </span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-sm text-black">Completed</span>
                            <span className="text-sm font-medium">
                                {appointments.filter(apt => apt.Status === 'Completed').length}
                            </span>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                    <h3 className="text-lg font-medium text-black mb-4">Next Appointment</h3>
                    {appointments.length > 0 ? (
                        <div className="space-y-2">
                            <p className="text-sm font-medium">{appointments[0].Doctor.User.Name}</p>
                            <p className="text-sm text-black">{appointments[0].Doctor.Specialty.Name}</p>
                            <p className="text-xs text-black">
                                {new Date(appointments[0].AppointmentDate).toLocaleDateString()} at {appointments[0].StartTime}
                            </p>
                        </div>
                    ) : (
                        <p className="text-sm text-black">No upcoming appointments</p>
                    )}
                </div>
            </div>

            {/* Recent Appointments */}
            <div className="bg-white rounded-lg shadow">
                <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-medium text-black">Recent Appointments</h3>
                </div>
                <div className="divide-y divide-gray-200">
                    {appointments.slice(0, 5).map((appointment) => (
                        <div key={appointment.Id} className="p-6">
                            <div className="flex items-start justify-between">
                                <div className="flex-1">
                                    <div className="flex items-center mb-2">
                                        <h4 className="text-sm font-medium text-black mr-2">
                                            Dr. {appointment.Doctor.User.Name}
                                        </h4>
                                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(appointment.Status)}`}>
                                            {getStatusIcon(appointment.Status)}
                                            <span className="ml-1">{appointment.Status}</span>
                                        </span>
                                    </div>
                                    <p className="text-sm text-black mb-1">{appointment.Doctor.Specialty.Name}</p>
                                    <div className="flex items-center text-xs text-black space-x-4">
                                        <div className="flex items-center">
                                            <Calendar className="h-3 w-3 mr-1" />
                                            {new Date(appointment.AppointmentDate).toLocaleDateString()}
                                        </div>
                                        <div className="flex items-center">
                                            <Clock className="h-3 w-3 mr-1" />
                                            {appointment.StartTime} - {appointment.EndTime}
                                        </div>
                                    </div>
                                    {appointment.ReasonForVisit && (
                                        <p className="text-xs text-black mt-2">
                                            Reason: {appointment.ReasonForVisit}
                                        </p>
                                    )}
                                </div>
                                <div className="text-right">
                                    <p className="text-sm font-medium text-black">
                                        ${appointment.ConsultationFee}
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                    {appointments.length === 0 && (
                        <div className="p-6 text-center text-black">
                            <Calendar className="h-12 w-12 mx-auto mb-4 text-black" />
                            <p>No appointments found</p>
                            <button
                                onClick={() => router.push('/patient/book-appointment')}
                                className="mt-2 text-blue-600 hover:text-blue-500 text-sm font-medium"
                            >
                                Book your first appointment
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
